Dear Webmaster Business Masters Course registrant,

It's takes more than just strong design skills to create a
profitable Webmastering business.  Just like any other
venture offline or online, a solid foundation and operating
framework are critical for longterm success.  

Creativity on its own is not enough to generate income, and
more importantly, recurring income.  You need business
smarts as well.

The Webmaster BUSINESS Masters Course will get you started
in the right direction.  (Or put you "back" on track --
if you were concentrating too much on site-building and
let the "business side" slip).  Regardless of your present
situation, the Course will provide the information and
resources you need to secure your future as a flourishing
Webmaster.

--

So why are we offering this book for free?

It's our hope that you'll see that the most cost-and-time
effective way to build a successful business is by using the
two affordable tools highlighted in The Webmaster BUSINESS
Course...

o  "Start Your Own Home-Based Design Business" -- an e-book
written by Mark Frank, a Web professional who is a
successful independent designer.  This excellent resource
will shorten your learning curve and help you avoid common
mistakes.  Mark even provides customizable templates (for
example, a legal contract) so that you can get up and
running faster and with more confidence.


o  "Site Build It!" -- an all-in-one site-building,
site-hosting, and site-marketing solution that will increase
your productivity level and help you deliver an attractive,
traffic-generating site (51% of active SBI! sites fall
within the top 6% most popular sites on the Internet) in
less time, and at a solid profit.  

The SBI! system works without compromising design or site
functionality (has HTML editor and graphic software
compatibility) and its backend automation takes care of the
tedious, time-consuming tasks.

--

OK.  Ready to begin?

In your "Webmaster Business Masters Course" folder, you have
2 files...

1)  ReadMeFirst.txt -- that's what you are reading now!

2)  webmasterbusiness.pdf -- The Webmaster BUSINESS Masters
Course concentrates on the critical start-up phase where you
can make or break your business.  Follow its guidance and
you will "make" it... with fewer trial and error experiments.  

Just DOUBLE-CLICK on "webmasterbusiness.pdf" to open the file.

SPECIAL NOTE:  You need ADOBE ACROBAT READER 3 (or higher)
to use the Guide.  If you do not have it, please download
now.  It only takes a few minutes to download and install
this free (and fantastic!) software.

http://www.adobe.com/products/acrobat/readstep2.html

--

There is no time like the present to get started on the
Course and your business.  The demand for Web sites and
Webmasters continues to grow daily -- especially in the
huge SSB (Small Small Business) market.  Upgrade your
business skills to the level of your designing skills and
set the scene for success... for you AND for your clients!

"Getting down to business" has never been so smooth.  Enjoy
the ride!

All the best, 
Ken Evoy
President, SiteSell.com















